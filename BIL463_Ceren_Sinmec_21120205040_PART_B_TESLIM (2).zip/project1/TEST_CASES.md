# Luma test case checklist (20 cases)

1 let -> LET
2 if -> IF
3 while -> WHILE
4 ifx -> IDENTIFIER
5 _name2 -> IDENTIFIER
6 42 -> INTEGER
7 3.14 -> FLOAT
8 .5 -> FLOAT
9 2. -> FLOAT
10 1e10 -> FLOAT
11 2.5E-3 -> FLOAT
12 == -> EQ
13 <= -> LE
14 && -> AND
15 || -> OR
16 // comment -> ignored
17 /* multiline comment */ -> ignored and line count updated
18 @ -> ERROR, scanning continues
19 # -> ERROR, scanning continues
20 = -> ASSIGN

These cases are covered across tests/test1.txt through test3.txt.
