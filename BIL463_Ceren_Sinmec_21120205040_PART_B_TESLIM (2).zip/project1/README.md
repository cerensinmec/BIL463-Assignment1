# Luma - BIL 463 Assignment 1 (Part B)
Student: Ceren Sinmeç | ID: 21120205040 | Individual submission (instructor approval required for Part B).

Path B: Python + PLY. AI assistance: OpenAI ChatGPT (GPT-6), used to draft lexer, tests and documentation. Verify and explain code before submitting.

## Run
```bash
python -m pip install -r requirements.txt
python src/lexer.py tests/test1.txt
python src/lexer.py tests/test2.txt
python src/lexer.py tests/test3.txt
python src/bpe_compare.py tests/test1.txt tests/test2.txt tests/test3.txt
```

Expected lexer outputs are in output/. The BPE comparison requires tiktoken and must be run on your machine if unavailable in the build environment.

Part A is not included because the instructor requires it to be handwritten by the student.

## Automated regression tests
```bash
python -m unittest discover -s tests -p "test_*.py" -v
```
22 automated tests were executed on Windows (Python 3.14 / PLY 3.11): Ran 22 tests in 0.016s, OK. Tests cover keywords, numeric formats, multi-character operators, comments, line numbers and error recovery. An unclosed `/*` reports one error and does not emit comment contents as tokens.

BPE verification on Windows (tiktoken 0.14.0): test1 51/58, test2 61/82, test3 27/42 (lexer/BPE). Totals: 139/182. Turkish sentence: 16 BPE tokens.
