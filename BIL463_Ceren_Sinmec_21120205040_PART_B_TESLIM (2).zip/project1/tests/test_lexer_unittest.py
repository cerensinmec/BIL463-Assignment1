"""Run from project1: python -m unittest discover -s tests -p "test_*.py" -v"""
import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from lexer import tokenize

def types(s):
    return [line.split(': ',1)[1].split(' ',1)[0] for line in tokenize(s) if not line.startswith('ERROR')]

class LexerTests(unittest.TestCase):
    def test_keyword(self): self.assertEqual(types('if'),['IF'])
    def test_keyword_prefix(self): self.assertEqual(types('ifx'),['IDENTIFIER'])
    def test_identifier_underscore(self): self.assertEqual(types('_x2'),['IDENTIFIER'])
    def test_identifier_case(self): self.assertEqual(types('If'),['IDENTIFIER'])
    def test_integer(self): self.assertEqual(types('42'),['INTEGER'])
    def test_decimal(self): self.assertEqual(types('3.14'),['FLOAT'])
    def test_leading_decimal(self): self.assertEqual(types('.5'),['FLOAT'])
    def test_trailing_decimal(self): self.assertEqual(types('2.'),['FLOAT'])
    def test_exponent(self): self.assertEqual(types('1e10'),['FLOAT'])
    def test_signed_exponent(self): self.assertEqual(types('2.5E-3'),['FLOAT'])
    def test_equal(self): self.assertEqual(types('=='),['EQ'])
    def test_assignment(self): self.assertEqual(types('='),['ASSIGN'])
    def test_le(self): self.assertEqual(types('<='),['LE'])
    def test_and(self): self.assertEqual(types('&&'),['AND'])
    def test_or(self): self.assertEqual(types('||'),['OR'])
    def test_comment_line(self): self.assertEqual(types('// ignored\nlet'),['LET'])
    def test_comment_block(self): self.assertEqual(types('/* ignored */let'),['LET'])
    def test_block_newline(self): self.assertEqual(tokenize('/* a\nb */\nlet'),["3: LET 'let'"])
    def test_invalid_recovery(self):
        out=tokenize('let @ x')
        self.assertIn("ERROR line 1: illegal character '@'",out)
        self.assertEqual(types('let @ x'),['LET','IDENTIFIER'])
    def test_unterminated_block(self):
        out=tokenize('let x; /* not closed\nmore')
        self.assertEqual([v for v in out if v.startswith('ERROR')],['ERROR line 1: unterminated block comment'])
        self.assertEqual(types('let x; /* not closed'),['LET','IDENTIFIER','SEMICOLON'])
    def test_adjacent_operators(self): self.assertEqual(types('a!=b'),['IDENTIFIER','NE','IDENTIFIER'])
    def test_reset_line_numbers(self):
        tokenize('\n\nlet')
        self.assertEqual(tokenize('let'),["1: LET 'let'"])

if __name__=='__main__': unittest.main()
