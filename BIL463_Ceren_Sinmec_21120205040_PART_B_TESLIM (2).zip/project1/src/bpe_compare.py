"""Run after installing ply and tiktoken."""
import sys
from pathlib import Path
import tiktoken
from lexer import tokenize

enc = tiktoken.encoding_for_model('gpt-4')
for filename in sys.argv[1:] or sorted(str(p) for p in Path('tests').glob('*.txt')):
    content = Path(filename).read_text(encoding='utf-8')
    lexical = tokenize(content)
    bpe = enc.encode(content)
    print(f'{filename}: lexer={sum(not x.startswith("ERROR") for x in lexical)}, BPE={len(bpe)}')
    print('BPE first 20:', [enc.decode([x]) for x in bpe[:20]])
phrase = '"Derleyici belirteçleri ayrıştırır"'
ids = enc.encode(phrase)
print('Turkish sentence:', len(ids), [enc.decode([x]) for x in ids])
print('42:', [enc.decode([x]) for x in enc.encode('42')])
print('@:', [enc.decode([x]) for x in enc.encode('@')])
