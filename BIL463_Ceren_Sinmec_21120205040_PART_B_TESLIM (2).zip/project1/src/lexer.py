"""Luma lexer using PLY (pip install ply)."""
import sys
from pathlib import Path
try:
    import ply.lex as lex
except ImportError:
    raise SystemExit("Install dependency: python -m pip install ply")

reserved = {word: word.upper() for word in ('let', 'if', 'else', 'while', 'for', 'return', 'print', 'true', 'false')}
tokens = ('IDENTIFIER', 'INTEGER', 'FLOAT', 'EQ', 'NE', 'LE', 'GE', 'AND', 'OR', 'ASSIGN', 'LT', 'GT', 'PLUS', 'MINUS', 'TIMES', 'DIVIDE', 'MOD', 'NOT', 'LPAREN', 'RPAREN', 'LBRACE', 'RBRACE', 'SEMICOLON', 'COMMA') + tuple(reserved.values())

t_EQ = r'=='
t_NE = r'!='
t_LE = r'<='
t_GE = r'>='
t_AND = r'&&'
t_OR = r'\|\|'
t_ASSIGN = r'='
t_LT = r'<'
t_GT = r'>'
t_PLUS = r'\+'
t_MINUS = r'-'
t_TIMES = r'\*'
t_DIVIDE = r'/'
t_MOD = r'%'
t_NOT = r'!'
t_LPAREN = r'\('
t_RPAREN = r'\)'
t_LBRACE = r'\{'
t_RBRACE = r'\}'
t_SEMICOLON = r';'
t_COMMA = r','
t_ignore = ' \t\r'
errors = []

def t_COMMENT_BLOCK(t):
    r'/\*[\s\S]*?\*/'
    t.lexer.lineno += t.value.count('\n')

def t_UNTERMINATED_BLOCK_COMMENT(t):
    r'/\*(?![\s\S]*?\*/)[\s\S]*'
    errors.append(f'ERROR line {t.lineno}: unterminated block comment')
    t.lexer.lineno += t.value.count('\n')

def t_COMMENT_LINE(t):
    r'//[^\n]*'
    pass

def t_FLOAT(t):
    r'(?:[0-9]+\.[0-9]*|\.[0-9]+)(?:[eE][+-]?[0-9]+)?|[0-9]+[eE][+-]?[0-9]+'
    return t

def t_INTEGER(t):
    r'[0-9]+'
    return t

def t_IDENTIFIER(t):
    r'[a-zA-Z_][a-zA-Z_0-9]*'
    t.type = reserved.get(t.value, 'IDENTIFIER')
    return t

def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

def t_error(t):
    errors.append(f'ERROR line {t.lexer.lineno}: illegal character {t.value[0]!r}')
    t.lexer.skip(1)

def tokenize(source):
    errors.clear()
    lexer = lex.lex()
    lexer.lineno = 1
    lexer.input(source)
    result = [f'{tok.lineno}: {tok.type} {tok.value!r}' for tok in iter(lexer.token, None)]
    return result + errors

if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python src/lexer.py tests/test1.txt')
    print('\n'.join(tokenize(Path(sys.argv[1]).read_text(encoding='utf-8'))))
